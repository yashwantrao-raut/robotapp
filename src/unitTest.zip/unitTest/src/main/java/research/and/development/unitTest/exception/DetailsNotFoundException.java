package research.and.development.unitTest.exception;

/**
 * Created by kkularatne on 17/10/2017.
 */
public class DetailsNotFoundException extends Exception {
    public DetailsNotFoundException() {
    }
}
