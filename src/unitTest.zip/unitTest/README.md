# Spock unit test for Spring boot
getting started guide to create unit test in spring boot application using Spock Framework and groovy.
This shows adding unit tests for REST api and spring service using Spock test framework and groovy.
